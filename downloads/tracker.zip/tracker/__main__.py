from . import scripts

if __name__ == '__main__':
    scripts.tracker()
