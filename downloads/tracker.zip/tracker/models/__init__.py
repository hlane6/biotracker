""" Module containing all models used within the application.
"""
