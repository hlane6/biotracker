""" Module contains utility scripts to run the tracker on input files
"""
from .tracker_app import tracker
from .gen_vid_app import genvid

__all__ = [
    'tracker',
    'genvid'
]
